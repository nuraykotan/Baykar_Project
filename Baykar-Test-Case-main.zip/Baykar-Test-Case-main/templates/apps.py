from django.apps import AppConfig


class TemplatesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField' #model varsa primary key nasıl tanımlar.
    name = 'templates' # uygulama adını tanımlar.
