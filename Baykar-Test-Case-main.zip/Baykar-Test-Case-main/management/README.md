# Management Uygulaması Detayları

## Swagger Dökümanları

### Dataset Bilgileri
<img src="../resources/management-produce-dataset.png" alt="management-produce-dataset">
<img src="../resources/management-montage-dataset.png" alt="management-montage-dataset">

### Parça Yönetim Bilgileri
<img src="../resources/management-itemtypes.png" alt="management-get-item-types">
<img src="../resources/management-produce-item.png" alt="management-produce-item">
<img src="../resources/management-recycle-item.png" alt="management-recycle-item">

### Montaj Yönetim Bilgileri

<img src="../resources/management-get-montaged.png" alt="management-get-montaged">
<img src="../resources/management-montage-plane.png" alt="management-montage-plane">
<img src="../resources/management-get-plane-types.png" alt="management-get-plane-types">