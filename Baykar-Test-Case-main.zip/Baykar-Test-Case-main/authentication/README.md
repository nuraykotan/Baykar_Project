# Authentication Uygulaması Detayları



## Swagger Dökümanları

<img src="../resources/auth_login.png" alt="login-doc">

<img src="../resources/auth-whoami.png" alt="whoami-doc">

<img src="../resources/auth_logout.png" alt="logout-doc">